#ifndef __SYSTICK_H
#define __SYSTICK_H
#include  "stm32f10x.h"
void SYSTICK_Delay_ms(uint32_t ms);
#endif
