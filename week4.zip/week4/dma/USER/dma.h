#ifndef __DMA_H
#define __DMA_H
#define SendBuff_Size 5000
#define USART1_DR_Base 0x40013804
#include "stm32f10x.h"
#include "misc.h"
static void NVIC_Config(void);
void DMA_Config(void);
#endif
