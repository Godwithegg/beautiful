#include "stm32f10x.h"
#include "led.h"
#include "SysTick.h"
#include "dma.h"
#include "usart.h"
uint16_t i;
extern uint8_t SendBuff[SendBuff_Size];
int main()
{
	USART_Config();
	DMA_Config();
	LED_GPIO_Config();
	
	for(i=0;i<SendBuff_Size;i++)
	{
		SendBuff[i]=0xff;
	}
	USART_DMACmd(USART1,USART_DMAReq_Tx,ENABLE);
	LED1(ON);
	while(1);
	
	
}


