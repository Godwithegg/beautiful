#ifndef __USART_H
#define __USART_H
#include "stm32f10x.h"
#include <stdio.h>
#include "stm32f10x_usart.h"
#include "misc.h"
void NVIC_Config(void);
void USART_Config(void);
void USART_SendByte(USART_TypeDef *pUSART,uint8_t data);
void USART_SendByte2(USART_TypeDef *pUSART,uint16_t data);
void USART_SendArray(USART_TypeDef *pUSART,uint8_t *Array,uint8_t num);
void USART_SendString(USART_TypeDef *pUSART,char *str);
int fputc(int ch,FILE *f);

#endif
