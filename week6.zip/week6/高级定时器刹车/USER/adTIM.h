#ifndef __ADTIM_H
#define __ADTIM_H
#include "stm32f10x.h"
void ADVANCED_Config(void);
#endif
