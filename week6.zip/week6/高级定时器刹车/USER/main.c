#include "stm32f10x.h"
#include "exti.h"
#include "usart.h"
#include "adTIM.h"
int main()
{
	ADVANCED_Config();
	while(1);
	
	
}


