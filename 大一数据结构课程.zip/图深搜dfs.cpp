
#include<stdio.h>
#define M 8
main()
{
    int a[M][M]={0,1,1,0,0,0,0,0,
                 1,0,0,1,1,0,0,0,
                 1,0,0,0,0,1,1,1,
                 0,1,0,0,1,0,0,0,
                 0,1,0,1,0,0,0,0,
                 0,0,1,0,0,0,1,0,
                 0,0,1,0,0,1,0,0,
                 0,0,1,0,0,0,0,0
                };
    int mark[M]={0},k,b[M],top,i;
    top=0;
    b[top]=0;
    mark[0]=1;
    printf("%d ",b[top]);
    while(top>=0)
    {
        k=b[top];
        for(i=0;i<M;i++)
            if(a[k][i]==1&&mark[i]==0)
        {
            printf("%d ",i);
            b[++top]=i;
            mark[i]=1;
            break;
        }
        if(i==M)
            top--;
    }
}
