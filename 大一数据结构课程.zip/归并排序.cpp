
#include<stdio.h>
void f1(int a[],int b[],int s,int m,int t)
{
    int i,j,k;
    i=s;
    j=m+1;
    k=s;
    while(i<=m&&j<=t)
    {
        if(a[i]<=a[j])
            b[k++]=a[i++];
        else b[k++]=a[j++];

    }
    while(i<=m)
        b[k++]=a[i++];
    while(j<=t)
        b[k++]=a[j++];

}
void f2(int a[],int b[],int m,int n)
{
    int i=0,j;
    while(i+2*m<n)
    {
        f1(a,b,i,i+m-1,i+2*m-1);
        i=i+2*m;
    }
    if(i+m<n)f1(a,b,i,i+m-1,n-1);
    else while(i<n)
    {
        b[i]=a[i];
        i++;
    }
}
main()
{
    int a[100]={3,2,4,1,5,6};
    int b[100],n=6,i;
    int m=1;
    while(m<n)
    {
        f2(a,b,m,n);
        m*=2;
        f2(b,a,m,n);
        m*=2;
    }
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
}
