
#include<stdio.h>
main()
{
    int a[100]={7,2,10,4,1,6,20};
    int x[100],y[100],top,n,k;
    int left,right,t1,t2;
    n=7;
    top=0;
    x[top]=0;
    y[top]=n-1;
    while(top>=0)
    {
        left=x[top];
        right=y[top];
        k=a[left];
        top--;
        t1=left;
        t2=right;
        while(left<right)
        {
            while(a[right]>k&&left<right)
                right--;
            a[left]=a[right];
            while(a[left]<k&&left<right)
                left++;
            a[right]=a[left];
        }
        a[left]=k;
        if(t1<left-1)
        {
            top++;
            x[top]=t1;
            y[top]=left-1;
        }
        if(left+1<t2)
        {
            top++;
            x[top]=left+1;
            y[top]=t2;
        }
    }
    for(t1=0;t1<n;t1++)
        printf("%d ",a[t1]);
}
