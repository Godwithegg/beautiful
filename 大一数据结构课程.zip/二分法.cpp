
#include<stdio.h>
#define M 100
int main()
{
    int a[M]={4,3,5,1,7};
    int i,p1,p2,x,p,k;
    int n=5;
    p1=0;
    p2=n-1;
    x=5;
    do
        {
            p=(p1+p2)/2;
            if(a[p]>x)
                p2=p-1;
            else if(a[p]<x)
                p1=p+1;
            else
                {
                    k=p;
            break;
                }

        }while(p1<=p2);
        printf("%d",k);
}
