
#include<stdio.h>
struct node
{
    int x;
    node *next;
};
int main()
{
    node *head,*q,*p;
    int i,x;
    int n;
    scanf("%d",&n);
    head=new node;
    head->next=NULL;
    q=head;
    for(i=0;i<n;i++)
    {
        scanf("%d",&x);
        p=new node;
        p->x=x;
        q->next=p;
        q=p;
    }
    p->next=NULL;
    p=head->next;
    while(p)
    {
        printf("%d ",p->x);
        p=p->next;
    }//����
    p=head->next;
    while(p!=NULL)
    {
        q=p->next;
        delete p;
        p=q;
    }//�ͷ�
    return 0;
}
