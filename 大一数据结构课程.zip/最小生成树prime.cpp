
#include<stdio.h>
#define M 7
int main()
{
    int a[M][M]={0,3,2,4,8,6,8,
                 3,0,1,8,4,8,8,
                 2,1,0,1,3,8,8,
                 4,8,1,0,5,3,5,
                 8,4,3,5,0,5,7,
                 6,8,8,3,5,0,6,
                 8,8,8,5,7,6,0
                 };
    int dist[M],path[M],i,d,k,w;
    for(i=0;i<M;i++)
    {
        dist[i]=a[i][0];
        path[i]=0;
    }
    for(i=0;i<M;i++)
    {
        d=10;
        for(k=0;k<M;k++)
            if(dist[k]>0&&dist[k]<d)
        {
            d=dist[k];
            w=k;
        }
        dist[w]=0;
        for(k=0;k<M;k++)
            if(dist[k]>a[w][k]&&dist[k]>0)
        {
            dist[k]=a[w][k];
            path[k]=w;
        }
    }
    for(i=1;i<M;i++)
    {
        printf("%d-%d ",i,path[i]);
    }
}
