
#include<stdio.h>
#define M 6
main()
{
    int a[M];
    int i,front,real,x;
    front=real=0;
    while((real+1)%M!=front)
    {
        scanf("%d",&x);
        a[real]=x;
        real=(real+1)%M;
    }//����
    while(real!=front)
    {
        printf("%d ",a[front]);
        front=(front+1)%M;
    }//����
}
