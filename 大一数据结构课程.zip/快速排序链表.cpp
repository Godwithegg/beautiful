
#include<stdio.h>
struct node
{
    int x;
    node *left,*right;
};
void show(node *p)
{
    if(p)
    {
        show(p->left);
        printf("%d ",p->x);
        show(p->right);
    }
}
main()
{
    int a[1000]={6,2,1,9,8,5,4};
    int n=7,i;
    node *p,*q,*head,*t;
    head=NULL;
    for(i=0;i<n;i++)
    {
        t=new node;
        t->x=a[i];
        t->left=t->right=NULL;

      if(head==NULL)
        head=t;
      else
      {
        p=head;
        while(p)
          {
            q=p;
            if(a[i]<p->x)
                p=p->left;
            else p=p->right;
          }
        if(a[i]<q->x)
            q->left=t;
        else q->right=t;
      }
    }
    show(head);
}
