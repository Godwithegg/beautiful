
#include<stdio.h>
#define M 6
#define MAX 200
main()
{
    int a[M][M]={0,MAX,10,MAX,30,100,
		         MAX,0,5,MAX,MAX,MAX,
		         MAX,MAX,0,50,MAX,MAX,
		         MAX,MAX,MAX,0,MAX,10,
		         MAX,MAX,MAX,20,0,60,
		         MAX,MAX,MAX,MAX,MAX,0};
    int mark[M]={0},dist[M],path[M];
    int d,i,k,w;
    for(i=0;i<M;i++)
    {
        dist[i]=a[0][i];
        path[i]=0;
    }
    mark[0]=1;
    d=MAX+1;
    for(k=0;k<M;k++)
    {
        for(i=0;i<M;i++)
      if(dist[i]<d&&mark[i]==0)
      {
        d=dist[i];
        w=i;
      }
      mark[w]=1;
      for(i=0;i<M;i++)
        if(mark[i]==0)
      {
        d=dist[w]+a[w][i];
        if(d<dist[i])
        {
            dist[i]=d;
            path[i]=w;
        }
      }
    }
    for(i=1;i<M;i++)
    {
        k=i;
        printf("%d ",k);
        do
        {
            printf("%d ",path[k]);
            k=path[k];
        }while(k);
        if(dist[i]==MAX)
            printf("no way!\n");
    }
}
