
#include<stdio.h>
void adj(int a[],int s,int m)
{
    int temp,i,j;
    i=s;
    j=2*i+1;
    temp=a[s];
    while(j<m)
    {
        if(j+1<m&&a[j]<a[j+1])j++;
        if(temp>a[j])break;
        a[i]=a[j];
        i=j;
        j=2*i+1;
    }
    a[i]=temp;
}
main()
{
    int a[100]={7,2,10,4,1,6,20,8};
    int n,i,t;
    n=8;
    for(i=n/2-1;i>=0;i--)
        adj(a,i,n);
    for(i=n-1;i>=0;i--)
    {
        t=a[0];
        a[0]=a[i];
        a[i]=t;
        adj(a,0,i);
    }
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
}
