
#include<stdio.h>
struct node
{
    int x;
    node *next;
};
main()
{
    node *p,*head,*q;
    int n,i,x;
    scanf("%d",&n);
    head=new node;
    head->next=NULL;
    q=head->next;
    for(i=0;i<n;i++)
    {
        scanf("%d",&x);
        p=new node;
        p->x=x;
        p->next=q;
        q=p;
    }
    head->next=p;
    p=head->next;
    while(p)
    {
        printf("%d ",p->x);
        p=p->next;
    }
}
