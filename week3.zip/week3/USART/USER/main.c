#include "stm32f10x.h"
#include "exti.h"
#include "usart.h"
#include <stdio.h>
int main()
{
	
	uint8_t array[10]={1,2,3,4,5,6,7,8,9};
	uint8_t ch;
//	char str[30]="shenmeshini";
	USART_Config();
	//USART_SendString(USART1,str);
  // printf("whathappen");
	//USART_SendArray(USART1,array,10);
	//USART_SendString(USART1,"nishishui");
while(1)
	{
		scanf("%s",array);
		printf("%s",array);
	}
	
}


