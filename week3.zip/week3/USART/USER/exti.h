#ifndef __EXTI_NVIC_H
#define __EXTI_NVIC_H
void EXTI_NVIC_Config(void);
void EXTI_KEY_Config(void);
#endif