#ifndef __TIM_H
#define __TIM_H
#include "stm32f10x.h"
#include "misc.h"
void NVIC_Config(void);
void TIM_Config(void);
#endif
