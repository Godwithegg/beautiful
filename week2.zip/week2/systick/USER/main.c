#include "keyled.h"
#include "led.h"
#include "stm32f10x.h"
#include "SysTick.h"
static __IO u32 TimingDelay;
int main()
{
	LED_GPIO_Config();
	LED1(KEY_ON);
	while(1)
	{
		LED1(KEY_ON);
		SysTick_Delay_us(100000);
		LED1(KEY_OFF);
		SysTick_Delay_us(100000);
	}
}
void TimingDelay_Decrement(void)
{
	if(TimingDelay!=0)
	{ 
		TimingDelay--;
	}
}