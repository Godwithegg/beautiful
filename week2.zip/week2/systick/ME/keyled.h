#ifndef __KEYLED_H
#define __KEYLED_H
#include "stm32f10x.h"
#define KEY_ON 1
#define KEY_OFF 0
void KEY_LED_Config();
u8 Key_Scan(GPIO_TypeDef *GPIOx,u16 GPIO_Pin);
void Delay(uint16_t ncount);
#endif