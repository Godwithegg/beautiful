#include "SysTick.h"
#include "stm32f10x.h"
#include "misc.h"
#include "led.h"
#include "exti.h"
int main()
{
	SysTick_Init();
	LED_GPIO_Config();
	LED1(1);
	
	EXTI_PE5_Config();
	while(1);
}
