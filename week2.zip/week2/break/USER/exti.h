#ifndef __EXTI_H
#define __EXTI_H
static void NVIC_Configuration();
void EXTI_PE5_Config();
#endif