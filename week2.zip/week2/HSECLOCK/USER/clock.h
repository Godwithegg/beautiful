#ifndef __CLOCK_H
#define __CLOCK_H
#include "stm32f10x.h"
void HSE_SetSysClock(uint32_t RCC_PLLMul_x);

#endif
