#include "stm32f10x.h"
#include "led.h"
#include "SysTick.h"
#include "clock.h"
int main()
{
	SysTick_Init();
	HSE_SetSysClock(RCC_PLLMul_9);
	LED_GPIO_Config();
	LED1(1);
  while(1)
	{
		LED1(1);
		Delay(0xFFFFF);
		LED1(0);
		Delay(0xFFFFF);
	}
	
}
